# DeobfBot — Discord Deobfuscation Bot

A Discord bot with a `.deob` command. Attach an obfuscated Lua/Luau script,
pick the obfuscator from a dashboard, and get the deobfuscated file back.

## What it does

```
User:  .deob  (+ attach script.lua)
Bot:   [Dashboard embed]  Choose the obfuscator below.
                          > 1. Luraph V15
                          > 2. Prometheus (WeAreDevs & Some forks)
       [Luraph V15] [Prometheus]   (gray buttons)

User clicks a button:
Bot:   [Deobfuscating...]  ⏳ Processing...

Bot finishes:
Bot:   @User Here you go!
       [File Preview embed]  ``` first 5 lines of deobfuscated file ```
       footer: Today at HH:MM AM/PM PH
       + full deobfuscated file attached
```

## Engines included

- **Luraph V15** → `engines/deobf/` (Python, dynamic devirtualizer + trace)
- **Prometheus** (WeAreDevs & forks) → `engines/prometheus/` (Node.js)

Both run as isolated subprocesses per job (as their authors recommend).

## Setup

### 1. Requirements
- Python 3.10+
- Node.js 18+ (for the Prometheus engine)
- A Discord bot token (https://discord.com/developers/applications)
  - **Enable the "Message Content Intent"** on the Bot page (needed for `.deob` prefix commands).
  - Invite the bot with `bot` scope and `Send Messages`, `Embed Links`, `Attach Files`, `Read Message History` permissions.

### 2. Install Python deps
```bash
pip install -r requirements.txt
```

### 3. Put your token in `config.json`
```json
{ "token": "YOUR_TOKEN_HERE", "prefix": "." }
```
(Or set the `DISCORD_TOKEN` environment variable instead.)

### 4. Build the Luau binary (needed for Luraph V15)
The Luraph engine runs your script inside a real Luau VM. You must build
`luau` and `luau-ast` and place them in `engines/deobf/deobf/bin/`.

**Windows:**
```bash
cd engines/deobf
python deobf/build_luau.py
```
This produces `deobf/bin/luau.exe` and `deobf/bin/luau-ast.exe`.

**Linux / macOS:** build Luau from source (CMake) and place the `luau` and
`luau-ast` binaries in `engines/deobf/deobf/bin/` (the harness looks for
`luau` / `luau.exe` there). The Prometheus engine does NOT need this.

### 5. Run
```bash
python bot.py
```

## Deploying on Render

This bot needs Python + Node.js + a compiled Luau binary, so use the included
**Dockerfile** (a native Python service will not work).

**Easy path (recommended):**
1. Push this folder to a GitHub repo.
2. In Render → New + → **Background Worker** → connect the repo. Render
   auto-detects `render.yaml` and the `Dockerfile`.
3. Set the `DISCORD_TOKEN` environment variable (secret) in the Render
   dashboard.
4. Deploy. First build takes ~5–10 min (it compiles Luau from source).

**Cost note:** Render's Background Workers are paid (Starter plan ~$7/mo);
there is no free worker tier. Free **Web Services** sleep after inactivity,
which takes the bot offline. If you still want to try the free tier, change
`type: worker` to `type: web` in `render.yaml` — the bot starts a tiny
health-check HTTP server on `$PORT` so Render sees it as live. Use an external
pinger (e.g. UptimeRobot) to reduce sleeping, and expect downtime.

The Docker image is self-contained: it installs Python + Node, builds the
patched `luau` and `luau-ast` binaries, and installs Python deps. No manual
Luau build step is needed when using Docker.

## Usage
In any channel the bot can see:
```
.deob   (with a .lua / .luau / .txt file attached)
```
Then click **Luraph V15** or **Prometheus**. Only the person who ran the
command can click the buttons. The dashboard times out after 2 minutes.

## Notes
- Max file size: 25 MB.
- Deobfuscation can take up to ~5 minutes for big Luraph scripts (the bot
  shows a loading embed while it works).
- If you pick the wrong obfuscator, the bot tells you and you can re-run
  `.deob` and pick the other one.
- The full deobfuscated file is always attached to the result message; the
  embed only shows the first 5 lines as a preview.
